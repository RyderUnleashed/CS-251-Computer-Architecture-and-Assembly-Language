#include "stdio.h"
/*****************************************************
* Description: Endianness refers to whether the bytes in a word are ordered starting with the most-significant byte first (big-endian)
	       or the least-significant byte first (little-endian). Endianness only impacts the ordering of bytes; the bits within the
	       byte remain in the same order. Ex: 00001111 remains 00001111 for either big or little endian formats, and does not become 11110000.
	       In the program below, an example of big-endian and little-endian formats are shown, and the bytes of 15 and their respective memory
	       locations are printed, determining the endianness of the computer's memory.
* Author: Alex Griep
* Date: 2023/03/29
*****************************************************/
// In a big endian system, the most significant byte comes first
// In a little endian system, the least significant byte comes first
// The value stored in either system doesn't necessarily change
// i.e., no matter big endian or little endian, it'll always be the value stored


int main(void)
{

	// We're setting the int we want to test to 15 as it's an easy hex value to check
	int testInt = 15;
	printf("\n\nHexadecimal value of 15: 0x%.8x", testInt);

	// Let's assume that the user is skeptical, let's demonstrate and explain
	printf("\n\nIn a Big Endian format, 15 would be stored as:\n");
	printf("+----+----+----+----+\n");
	printf("|0x00|0x00|0x00|0x0f|\n");
	printf("+----+----+----+----+\n");
	printf("At memory addresses:\n");
	printf("+----+----+----+----+\n");
	printf("|0x01|0x02|0x03|0x04|\n");
	printf("+----+----+----+----+\n\n");
	printf("In a Little Endian format, 15 would be stored as:\n");
	printf("+----+----+----+----+\n");
	printf("|0x0f|0x00|0x00|0x00|\n");
	printf("+----+----+----+----+\n");
	printf("At memory addresses:\n");
	printf("+----+----+----+----+\n");
	printf("|0x01|0x02|0x03|0x04|\n");
	printf("+----+----+----+----+\n");


	// Now, we'll print the charPointer for the testInt above at their respective memory locations
	printf("\n15 is currently being stored as:\n");
	char* charPointer = (char *) &testInt;
	printf("+----+----+----+----+\n");

	printf("|");
	for(int i = 0; i < sizeof(int); i++)
	{
		printf("0x%.2x|", *(charPointer + i));
	}
	printf("\n");

	printf("+----+----+----+----+\n");
	printf("At memory addresses:\n");
	printf("+----+----+----+----+\n");
	printf("|0x01|0x02|0x03|0x04|\n");
	printf("+----+----+----+----+\n");

	// Now, we'll use in "if-else" statement and some pointer arithmetic to determine endianness
	printf("\nTherefore, this computer's memory is ");
	if (*charPointer == testInt) // If the first spot equals the integer being tested,
	{			     // it's little endian
		printf("Little Endian \n\n");
	}
	else // Otherwise, the most significant byte is being stored first
	{
		printf("Big Endian \n\n");
	}

	return 0;
}



