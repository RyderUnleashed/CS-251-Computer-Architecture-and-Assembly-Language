#include "stdio.h"
#include "string.h" // Needed for strlen()
/***************************************************************
* Description: Takes a signed floating point binary number and returns the decimal value and fractional bits
* Author: Alex Griep
***************************************************************/


#define MAX_BITS 32
#define MAX_LENGTH 49

// . . .

int last_index_of(char in_str[MAX_LENGTH], char ch)
{
	// Used for finding the dot in the decimal
	int index = -1;
	int i;
	for (i = strlen(in_str) - 1; i >= 0 && index == -1; --i)
	{
		if (in_str[i] == ch)
		{
			index = i;
		}
	}
	return index;
	// Return the largest index i such that in_str[i] == ch,
	// or -1 if no such index i exists
	// . . .
}


void sub_string(char in_str[], char out_str[],
		unsigned int start, unsigned int end)
{	/*
	After this function returns, out_str is a valid C string that
	contains the substring of in_str from start (inclusive) to end
	(exclusive). In other words:

	out_str[0] == in_str[start]
	out_str[1] == in_str[start + 1]
	. . .
	out_str[start + (end - start) - 1] == in_str[end - 1]
	out_str[start + (end - start) == '\0'; // terminating null

	You may assume that start <= end and in_str and out_str have
	the same capacity. If start == end, then out_str[0] == '\0'
	*/
	int i = 0;
	while (i <= (end - start))
	{
		out_str[i] = in_str[start + i];
		if (i == (end - start))
		{
			out_str[i] = '\0';
		}
		i++;
	}
}

int main(void)
{
	char input[MAX_LENGTH + 1]; // + 1 for thr terminating null
	char numberBits[MAX_BITS]; //Used for gathering the significand portion of the input
	char fractional[MAX_BITS << 1]; //Used for gathering the exponential portion of the input
	char positiveNegative = '+';
	signed int number = 0;
	int multiple = 1;
	int i = 0;

	printf("Enter a floating point value in binary: ");
	scanf("%s", input); // DO NOT put the & before 'input'

	// Fill in the missing details...

	sub_string(input, fractional, last_index_of(input, '.') + 1, strlen(input));
	sub_string(input, numberBits, 0, last_index_of(input, '.'));

	if (numberBits[0] == '1') //If the most significant bit is '1'
	{
		positiveNegative = '-'; //Initialize the sign with a negative sign
	}

	if (positiveNegative == '-') //If the sign is negative
	{
		for (i = 0; i < strlen(numberBits); i++)
		{
			numberBits[i] = numberBits[i] ^ 1; //Flip the bits
		}
	}

	for (i = strlen(numberBits) - 1; i >= 0; i--)
	{
		if (numberBits[i] == '1')
		{
			number += multiple; //If a bit is '1', add a multiple
		}
		multiple = multiple << 1; //Increase by a power of two
	}

	if (positiveNegative == '-')
	{
		number += 1; //If a negative sign is present, add one
		printf("-"); //print the sign
	}

	printf("%d", number);

	for (i = 0; i < strlen(fractional); i++)
	{
		if (fractional[i] == '1')
		{
			printf(" %c 1/%d", positiveNegative, 2 << i); //Print the sign and the power of two
		}
	}
	printf("\n");
	return 0;
}

// In Class examples:
/*
	char in_str[] = "Hello World"
	char out_str[12];

	sub_string(in_str, out_str, 2, 5);

	out_str[0] == 'l'
	out_str[1] == 'l'
	out_str[2] == 'o'
	out_str[3] == '\0'

------------------------------------------

	Let's say that the user typed in:
	 0     1     1   .  1      0      1
	 2^2 + 2^1 + 2^0 +  2^-1 + 2^-2 + 2^-3
*/
