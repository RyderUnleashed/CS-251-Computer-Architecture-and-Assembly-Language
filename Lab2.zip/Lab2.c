#include "stdio.h"

#define SIZE 16

int main(void)
{
	unsigned short int first = 0,
			   second = 0,
			   i,
			    a = 0,
			    b = 0,
			   rbit = 0,
			   cbit = 0,
			   carry_row = 0,
			   result_row = 0;

	printf("\n");

	printf("Enter first unsigned short: ");
	scanf("%hu", &first);
	printf("Enter second unsigned short: ");
	scanf("%hu", &second);

	for(i = 0; i < SIZE; i++) {
	  a = (first >> i) & 1;
	  b = (second >> i) & 1;
	  rbit = ((a ^ b) ^ cbit);
	  cbit = (a & b) | (b & cbit) | (cbit & a);
	  carry_row = carry_row | (cbit << i);
	  result_row = result_row | (rbit << i);
	}
	printf(" ");
	for(i = SIZE + 1; i > 0; i--) {
	  printf("%d",(1 & (carry_row >> i - 2)));
	}
	printf(" <= carry_row \n  ");
	for(i = SIZE; i > 0; i--) {
	  printf("%d", 1 & (first >> i - 1));
	}

	printf(" <= first \n+ ");
	for(i = SIZE; i > 0; i--) {
	  printf("%d", 1 & (second >> i - 1));
	}
	printf(" <= second \n -------------------  \n  ");

	for(i = SIZE; i > 0; i--) {
	  printf("%d", 1 & (result_row >> i - 1));
	}
	printf(" <= result \n ");

	unsigned short int overflow_bit = 1 & (carry_row >> SIZE - 1);
	if(overflow_bit) {
	  printf("!! Overflow detected !!");
	  printf("\n");
	}

	printf("\n");

	return 0;
}
