#include "stdio.h"
/************************************************
* Description: Allows the input two signed binary numbers and computes the result below
* Author: Alex Griep
* Date: 2023/02/22
************************************************/

#define MAX_BITS 101

int main(void)
{
   int bits1[MAX_BITS], bits2[MAX_BITS], bits3[MAX_BITS] /*, ...  */ ;
   int num_bits1 = 0, num_bits2 = 0, num_bits3 = 0 /*, ... */ ;
   int carry = 0;
   char bit;
   char sub;


   printf("\n");

   bit = getchar(); // Starts the first loop for getting the binary bits
   while ((bit == '0' || bit == '1') && num_bits1 < MAX_BITS - 1) //First loop for getting the binary bits,
								  //exits when anything other than 1 or 0 is entered
   {
	bits1[num_bits1] = bit - '0';
	num_bits1++;
	bit = getchar();
   }

   if (bit == '+') //If the user inputs a '+', initialize to 0
   {
	sub = 0;
	carry = 0;
   }
   else if (bit == '-') //If they input a '-', initialize to 1
   {
	sub = 1;
	carry = 1;
   }

   bit = getchar(); //Starts the second loop for getting the binary bits
   while ((bit == '0' || bit == '1') && num_bits2 < MAX_BITS - 1) //Second loop for getting the binary bits,
   {
	bits2[num_bits2] = bit - '0';
	num_bits2++;
	bit = getchar();
   }

   for (int i = 0; i < (num_bits1 >> 1); i++) //Reverses the first array
   {
	int tempVal = bits1[i];
	bits1[i] = bits1[num_bits1 - i - 1];
	bits1[num_bits1 - i - 1] = tempVal;
   }

   for (int i = 0; i < (num_bits2 >> 1); i++) //Reverses the second array
   {
	int tempVal = bits2[i];
	bits2[i] = bits2[num_bits2 - i - 1];
	bits2[num_bits2 - i - 1] = tempVal;
   }

   for (int i = num_bits1; i < MAX_BITS; i++) //Sign extends the bits of the first array
   {
	int signExtend = bits1[num_bits1 - 1];
	bits1[i] = signExtend;
   }


   for (int i = num_bits2; i < MAX_BITS; i++) //Sign extends the bits of the second array
   {
	int signExtend = bits2[num_bits2 - 1];
	bits2[i] = signExtend;
   }

   printf(" ");
   for (int i = num_bits1; i >= 0; i--) //Prints the bits of the first array
   {
	printf("%d", bits1[i]);
   }
   printf("\n");
   printf("+");

   for (int i = num_bits2; i < num_bits1; i++)
   {
	printf(" ");
   }

   for (int i = num_bits2; i >= 0; i--) //Prints the bits of the second array
   {
	printf("%d", bits2[i]);
   }
   printf("\n");

   for (int i = num_bits1 + 1; i >= 0; i--) //Prints the divider between the two numbers and the result
   {
	printf("-");
   }
   printf("\n");

   for (int i = 0; i < MAX_BITS; i++) //Computes the result bit array and the carry bit
    {
	bits3[i] = (bits1[i] ^ ((bits2[i] ^ sub) ^ carry));
	carry = (bits1[i] & bits2[i]) | ((bits2[i] ^ sub) & carry) | (carry & bits1[i]);
   }

   printf(" ");
   for (int i = num_bits1; i >= 0; i--) //Prints the bits for the result bit array
   {
	printf("%d", bits3[i]);
   }
   printf("\n");



   // Cannot use "bits1.length", must use MAX_BITS to loop through the array

   // bits3 declared above is what you'll use to store your result bits

   // In C, when you declare an array, it just gives you memory filled with garbage

   // The 'i' in the lab's code fragment should be "num_bits1[i]"

   // You also wanna loop while the bits are either a '0' or a '1'

   // Two code fragments are needed to read in the bits, refer to lab manual

   // Consider storing the bits in reverse order so that the least significant bit is at
   // the smallest index in the array

   //
   return 0;
}
