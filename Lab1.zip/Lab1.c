#include "stdio.h"
/*************************************************
* Description: Prompts the user to enter a valid unsigned short integer 
		and converts it to binary, counting the number of 0 bits
* Author: Alex Griep
* Date: 2/6/2023
*************************************************/


int main(void)
{
	unsigned short int num; // variable declaration
	printf("\nEnter a valid unsigned short: ");
	scanf("%hu", &num); // read an unsigned short int into num
	
	
	printf("You entered %hu\n", num); //print the value of "num", as
					  //an unsigned short int, after
					  //"entered"
	int bit = 1 & (num >> 15);
	int countOnes = countOnes + bit;
	printf("%d", bit);
	bit = 1 & (num >> 14);
	countOnes = countOnes + bit;
	printf("%d", bit);
	bit = 1 & (num >> 13);
	countOnes = countOnes + bit;
	printf("%d", bit);
	bit = 1 & (num >> 12);
	countOnes = countOnes + bit;
	printf("%d", bit);
	bit =  1 & (num >> 11);
	countOnes = countOnes + bit;
	printf("%d", bit);
	bit = 1 & (num >> 10);
	countOnes = countOnes + bit;
	printf("%d", bit);
	bit = 1 & (num >> 9);
	countOnes = countOnes + bit;
	printf("%d", bit);
	bit = 1 & (num >> 8);
	countOnes = countOnes + bit;
	printf("%d", bit);
	printf(" ");
	bit = 1 & (num >> 7);
	countOnes = countOnes + bit;
	printf("%d", bit);
	bit = 1 & (num >> 6);
	countOnes = countOnes + bit;
	printf("%d", bit);
	bit = 1 & (num >> 5);
	countOnes = countOnes + bit;
	printf("%d", bit);
	bit = 1 & (num >> 4);
	countOnes = countOnes + bit;
	printf("%d", bit);
	bit = 1 & (num >> 3);
	countOnes = countOnes + bit;
	printf("%d", bit);
	bit = 1 & (num >> 2);
	countOnes = countOnes + bit;
	printf("%d", bit);
	bit = 1 & (num >> 1);
	countOnes = countOnes + bit;
	printf("%d", bit);
	bit = 1 & (num >> 0);
	countOnes = countOnes + bit;
	printf("%d \n", bit);

	int numZeroes = 16 - countOnes;

	printf("Total number of 0 bits: %d\n\n", numZeroes);



	return 0;
}
