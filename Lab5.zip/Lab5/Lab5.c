#include "stdio.h"
#include "malloc.h" //Needed for amlloc, realloc and free
/********************************************************************************
*Description: Gathers an array of bits, allocating more memory if need be and
 inverts them, adding one and finally printing them out. Lab5 also includes a demo
 on pointer arithmetic
*Author: Alex Griep
*Date: 2023/03/15
********************************************************************************/




#define GROW_BY 2

// The following function must interpret the bits in in_array
// as an integer in binary with lsb at in_array[num-1]
// and msb at in_array[0]. The function must return with
// in_array updated to hold the bits of the result of
// adding one to the orignal value. The return value
// must be the final carry (out) bit, e.g.,
// if in_array[] = {0 , 1 , 1} and num == 3,
// then after add_one returns,
// in_array[] {1, 0, 0} and the value 0 is returned
// However, if in_array = {1, 1, 1} and num == 3, then
// after add_one returns, in_array[] = {0, 0, 0} and
// the value 1 is returned.
int add_one(int in_array[], int num)
{
	int cout = 0; // Initialize the carry out bit to 0
	int b = 1; // Initialize the adding bit to 1
	int rbit = 0; // Initialize the result bit to 0
	for (int i = num - 1; i >= 0; i--)
	{
		int a = in_array[i]; // The bit we want to compute with is the one at i, in the array
		rbit = ((a ^ b) ^ cout); // Computers the result bit
		cout = (a & b) | (b & cout) | (a & cout); // Computes the carry bit
		b = 0; // "Discards" the adding bit
		in_array[i] = rbit; // Sets the result to the index we're looking at
	}

	return cout; // Returns it?
}

// The following function assumes that every
// element of in_array holds either the value 0
// or 1 and must return with every element
// of in_array inverted from its initial value,
// i.e., 0 inverts to 1, and vice versa.
void flip_bits(int in_array[], int num) // Function to invert the bits in the passed in array
{

	for (int i = 0; i < num; i++) // While i is less than the number passed in, assuming it's the number of bits
	{
		in_array[i] = 1 ^ in_array[i]; // Invert the bit at i
	}

}

int main(void)
{
	printf("\n"); // Formatting for a cleaner output

	int* array; // Declares the array
	int num_bits, capacity = 0; // Initializes num_bits and capacity to 0, as we've entered nothing in there
	char bit; // Declares a char variable to gather bits

	array = (int*)malloc(sizeof(int)); // Allocates enough memory to store a byte the size of an int
	capacity = 1; // Since we've allocated memory, set the capacity to the size of an integer

	if (array == NULL)	// Checks to see if malloc failed
	{
		printf("!! Something went wrong -- malloc failed !!\n");
		return 1;
	}

	bit = getchar(); // Begins the loop to gather bits
	while ( bit != '\n' ) // While ENTER isn't pressed
	{

		if (num_bits >= capacity) // If we've reached capacity, allocate more by doubling it
		{
			// Out of capacity!!
			// "Grow" the array using realloc
			// Don't forget to check the return value!

			array = (int*)realloc(array, (num_bits * GROW_BY) * sizeof(int));
			capacity * GROW_BY;

		}

		if (bit == '0') // If the character entered == '0', store a 0
		{
			array[num_bits] = 0;
		}
		else // Otherwise, assuming the user follows the rules, store a 1
		{
			array[num_bits] = 1;
		}

		num_bits++; // Increase the number of bits stored in the pointer array
		bit = getchar(); // "Restart" the loop
	}

	flip_bits(array, num_bits); // Testing flip bits
	add_one(array, num_bits);

	for (int i = 0; i < num_bits; i++)
	{
		printf("%d", array[i]); // Prints the arrays after being flipped and added with 1
	}
	printf("\n\n");

	int *ip = NULL;
	printf("\nUsing pointer arthimetic:\n");
	for (ip = array; ip < array + num_bits; ip++)
	{
		printf(" array[%d] = %d (stored at address: %p)\n", (int)(ip - array), *ip, ip);
	}
	printf("\n"); // More formatting

	free(array); // Frees up the memory allocated to the array
	return 0;
}



/****************
Class Notes/Examples:
------------------------
- '&' The ampersand sign is how you store into the address itself

- When you assign 'NULL' into a value, it's best practice to not use it after

- When you nullify a variable, it's memory address doesn't change, but the value does

- Implement 'addOne' and 'flipBits' as efficiently as possible using bitwise operators
****************/
